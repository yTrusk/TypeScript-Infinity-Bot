declare namespace NodeJs {
    interface ProcessEnv {
        TOKEN: string
    }
}